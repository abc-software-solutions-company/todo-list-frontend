// Mock CSS files.
// If you're using CSS modules, this file can be deleted.
// Read more at "Handling stylesheets and image imports" on https://nextjs.org/docs/testing

module.exports = {};
