export const SECTION_CONFIGS = {
  SLIDESHOW: 'slideshow',
  INTRODUCTION: 'introduction',
  OUR_PROCESS: 'our-process',
  PRICING: 'pricing'
};
