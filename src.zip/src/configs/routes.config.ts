export const ROUTES = {
  HOME: '/',
  ACTION: '/action',
  TODO_LIST: '/list',
  QUICKPLAY: '/quick-play',
  NOTFOUND: '/not-found',
  WAITING: '/waiting'
};
