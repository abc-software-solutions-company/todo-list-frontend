export const MODULES = {
  language: {
    items: [
      {
        locale: 'en',
        name: 'English'
      },
      {
        locale: 'vi',
        name: 'Tiếng Việt'
      }
    ]
  }
};
