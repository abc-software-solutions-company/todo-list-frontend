export default function range(length: number) {
  return Array.from({length});
}
